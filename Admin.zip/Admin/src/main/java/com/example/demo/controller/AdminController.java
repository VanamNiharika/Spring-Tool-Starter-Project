package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Admin;
import com.example.demo.service.AdminService;

@RestController
public class AdminController {
	@Autowired
	AdminService as1;
	
	@PostMapping("/admin")
	public Admin saveAdmin(@RequestBody Admin admin) {
		return as1.saveAdmin(admin);
		
	}
	@GetMapping("/admin")
	public List<Admin> fetchAdminList(){
		return as1.fetchAdminByList();
		
	}
	@GetMapping("/admin/{id}")
	 public Admin fetchAdmintById(@PathVariable("id") Long adminId)
    {
        return as1.fetchAdminById(adminId);
    }
	 @DeleteMapping("/admin/{id}")
	 public String deleteAdminById(@PathVariable("id") Long adminId) 
	 {
	        as1.deleteAdminById(adminId);
	        return "Record deleted Successfully in Admin DB!!";
	 }
	 
	 @PutMapping("/admin/{id}")
	    public Admin updateAdmin(@PathVariable("id") Long adminId,
	                             @RequestBody Admin admin) {
	        return as1.updateAdmin(adminId,admin);
	 }	
}