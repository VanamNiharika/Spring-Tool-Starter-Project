package com.example.demo.service;

import java.util.List;

import com.example.demo.Entity.Admin;

public interface AdminService {

	public Admin saveAdmin(Admin admin);

	public List<Admin> fetchAdminByList();

	public Admin fetchAdminById(Long adminId);

	public void deleteAdminById(Long adminId);

	public Admin updateAdmin(Long adminId, Admin admin);

}
